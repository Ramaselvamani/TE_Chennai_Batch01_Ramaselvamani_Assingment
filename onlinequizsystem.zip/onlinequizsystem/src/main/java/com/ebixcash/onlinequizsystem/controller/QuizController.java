package com.ebixcash.onlinequizsystem.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.ebixcash.onlinequizsystem.bean.LoginBean;
import com.ebixcash.onlinequizsystem.bean.QuizBean;
import com.ebixcash.onlinequizsystem.service.QuizService;

@Controller
public class QuizController {

	@Autowired
	private QuizService service;
	
	@RequestMapping("/")
	public String getLoginPage() {
		return "Login";
	}

	@PostMapping("/login")
	public String userLogin(String userid, String password, HttpServletRequest request, ModelMap map) {
		LoginBean bean = service.userLogin(userid, password);
		if (bean != null) {
			HttpSession session = request.getSession(true);
			session.setAttribute("isLoggedIn", bean);
			Object aa = service.getCountOfData();
			System.out.println(aa);
			map.addAttribute("bean", bean);
			return "Main";
		} else {
			map.addAttribute("message", "Enter valid Credential");
			return "Login";
		}
	}

	@GetMapping("/testmainpage")
	public String userMain(@SessionAttribute(name = "isLoggedIn", required = false) LoginBean logBean, ModelMap map) {
		if (logBean != null) {
			QuizBean bean = service.getAll();
			if (bean != null) {
				map.addAttribute("allData", bean);
				return "MainTestPage";
			} else {
				map.addAttribute("message", "Something went wrong");
				return "Login";
			}
		} else {
			map.addAttribute("error", "Please login first");
			return "Login";
		}
	}

	@PostMapping("/validateanswer")
	public String answerValidation(@SessionAttribute(name = "isLoggedIn", required = false) LoginBean logBean,
			ModelMap map, String answer) {
		if (logBean != null) {
			QuizBean bean = service.validateAnswer(answer);
			if (bean != null) {
				if (bean.getCorrect_answer().equals(answer)) {
					map.addAttribute("data", bean);
					map.addAttribute("message", "Correct Answer");
					return "Validate";
				} else {
					map.addAttribute("data", bean);
					map.addAttribute("message", "Wrong Answer!");
					return "Validate";
				}
			} else {
				map.addAttribute("message", "Something went wrong");
				return "Login";
			}
		} else {
			map.addAttribute("message", "Please login first");
			return "Login";
		}
	}

	@GetMapping("/getresult")
	public String getResult(@SessionAttribute(name = "isLoggedIn", required = false) LoginBean logBean, ModelMap map) {
		if (logBean != null) {
			Integer result = service.getResult();
			if (result >= 0) {
				map.addAttribute("result", result);
				service.resultChange();
				return "Result";
			} else {
				map.addAttribute("message", "Something went wrong");
				return "Main";
			}
		} else {
			map.addAttribute("error", "Please login first");
			return "Login";
		}
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session, ModelMap map) {
		session.invalidate();
		map.addAttribute("message", "Logged out successfully ");
		return "Login";
	}
}
