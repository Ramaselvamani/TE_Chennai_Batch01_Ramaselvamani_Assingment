package com.ebixcash.onlinequizsystem.service;

import com.ebixcash.onlinequizsystem.bean.LoginBean;
import com.ebixcash.onlinequizsystem.bean.QuizBean;

public interface QuizService {

	LoginBean userLogin(String userid, String password);

	QuizBean getAll();

	Object getCountOfData();

	QuizBean validateAnswer(String answer);

	Integer getResult();

	void resultChange();

}
