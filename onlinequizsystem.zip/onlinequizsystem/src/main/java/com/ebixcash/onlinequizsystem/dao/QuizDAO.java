package com.ebixcash.onlinequizsystem.dao;

import com.ebixcash.onlinequizsystem.bean.LoginBean;
import com.ebixcash.onlinequizsystem.bean.QuizBean;

public interface QuizDAO {

	LoginBean userLogin(String userid, String password);

	QuizBean getAll();

	Object getCountOfData();

	QuizBean validate(String answer);

	Integer getResult();

	void resultChange();

}
