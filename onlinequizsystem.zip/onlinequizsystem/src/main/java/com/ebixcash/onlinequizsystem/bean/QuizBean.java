package com.ebixcash.onlinequizsystem.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Table(name = "questions")
@Entity
public class QuizBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	private Integer qno;
	
	@Column
	private String question;
	
	@Column
	private String answer1;
	
	@Column
	private String answer2;
	
	@Column
	private String answer3;
	
	@Column
	private String hint1;
	
	@Column
	private String hint2;
	
	@Column
	private String hint3;
	
	@Column
	private String correct_answer;
}
