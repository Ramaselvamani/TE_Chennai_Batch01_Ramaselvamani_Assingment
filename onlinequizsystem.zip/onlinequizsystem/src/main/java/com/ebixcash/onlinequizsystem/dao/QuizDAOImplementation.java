package com.ebixcash.onlinequizsystem.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.ebixcash.onlinequizsystem.bean.LoginBean;
import com.ebixcash.onlinequizsystem.bean.QuizBean;

@Repository
public class QuizDAOImplementation implements QuizDAO {

	Integer count;
	Integer result = 0;

	@Override
	public LoginBean userLogin(String userid, String password) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("quiz_unit");
			em = emf.createEntityManager();
			LoginBean bean = em.find(LoginBean.class, userid);
			if (bean != null) {
				if(password.equals(bean.getPassword())) {
					return bean;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer getCountOfData() {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("quiz_unit");
			em = emf.createEntityManager();
			String que = "select count(*) from QuizBean";
			Query query = em.createQuery(que);
			Object counts = query.getSingleResult();
			if (counts != null) {
				count = Integer.parseInt(counts.toString());
				return count;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public QuizBean getAll() {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("quiz_unit");
			em = emf.createEntityManager();
			QuizBean bean = em.find(QuizBean.class, count);
			if (bean != null) {
				return bean;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public QuizBean validate(String answer) {
		EntityManagerFactory emf = null;
		EntityManager em = null;
		try {
			emf = Persistence.createEntityManagerFactory("quiz_unit");
			em = emf.createEntityManager();
			QuizBean bean = em.find(QuizBean.class, count);
			if (bean != null) {
				count--;
				if (answer.equals(bean.getCorrect_answer())) {
					result++;
					return bean;
				} else {
					return bean;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer getResult() {
		return result;
	}

	@Override
	public void resultChange() {
		result = 0;
	}

}
