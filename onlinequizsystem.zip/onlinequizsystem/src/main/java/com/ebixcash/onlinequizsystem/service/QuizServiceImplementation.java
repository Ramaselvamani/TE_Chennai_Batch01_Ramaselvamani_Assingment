package com.ebixcash.onlinequizsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebixcash.onlinequizsystem.bean.LoginBean;
import com.ebixcash.onlinequizsystem.bean.QuizBean;
import com.ebixcash.onlinequizsystem.dao.QuizDAO;

@Service
public class QuizServiceImplementation implements QuizService {

	@Autowired
	private QuizDAO dao;

	@Override
	public LoginBean userLogin(String userid, String password) {
		if (userid != null && !userid.isEmpty()) {
			return dao.userLogin(userid, password);
		}
		return null;
	}

	@Override
	public QuizBean getAll() {
		return dao.getAll();
	}

	@Override
	public Object getCountOfData() {
		return dao.getCountOfData();
	}

	@Override
	public QuizBean validateAnswer(String answer) {
		return dao.validate(answer);
	}

	@Override
	public Integer getResult() {
		return dao.getResult();
	}

	@Override
	public void resultChange() {
		dao.resultChange();
	}

}
