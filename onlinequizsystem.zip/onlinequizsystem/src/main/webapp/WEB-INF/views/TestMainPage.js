const answer = document.getElementById('answer')
const correct = document.getElementById('correct')
console.log(answer)
function validate() {
	if(answer == correct){
		alert('Correct answer')
	} else {
		alert('wrong answer')
	}
}
